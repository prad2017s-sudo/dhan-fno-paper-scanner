# Dhan NSE F&O 5-minute Paper Trading Scanner

This is a **paper-trading starter project**. It does not place real orders.

## What it does
- Fetches 5-minute OHLCV candles from Dhan's Intraday Historical Data API.
- Scans the configured 10 NSE F&O stock underlyings.
- Uses an Advance/Decline bias entered by the user at 9:30 (Dhan's documented candle endpoint does not provide NSE-wide advance/decline breadth).
- Buy setup: a red candle (`close < open`) with volume lower than **every earlier candle of that session**. Buy trigger = setup candle high; SL = setup candle low.
- Sell setup: a green candle (`close > open`) with volume lower than **every earlier candle of that session**. Sell trigger = setup candle low; SL = setup candle high.
- Trigger is valid for the **next 5-minute candle only**. If not triggered in that candle, it logs `CANCELLED` and scans for another setup.
- Once entered, exits on SL or a 1:2 risk/reward target. If both target and SL are touched within the same candle, it conservatively assumes SL first.
- Writes candles, paper trades and cancelled setups to `paper_trading.xlsx`.

## Important limitations
1. This starter fetches candles for a selected date after the candles are available. It is a historical/replay foundation, **not yet a live streaming execution loop**.
2. Enter the 10 symbols and Dhan security IDs in `symbols.csv`. These IDs must be checked against Dhan's current instrument list. Use NSE cash-equity IDs for the stock underlyings, not option contract IDs.
3. At 9:30, enter NSE advances and declines from a reliable market-breadth source. The program uses `ADVANCES > DECLINES` as BUY bias and `DECLINES > ADVANCES` as SELL bias. Equal counts = no bias.
4. Historical candle API access may require the appropriate Dhan Data API access/subscription. See https://dhanhq.co/docs/v2/historical-data/
5. A historical candle can only tell that a price was touched within that 5-minute bar, not the exact tick sequence. Results are simulated, not guaranteed to match live fills.
6. Do not put your Dhan token in GitHub. Keep it in `.env`, which is ignored by Git.

## Setup (Android or computer)
1. Install Python 3.10+.
2. Extract this ZIP and open a terminal in this folder.
3. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
4. Copy `.env.example` to `.env`, then add your Dhan access token.
5. Edit `symbols.csv` with your chosen 10 F&O stocks and their verified security IDs.
6. Run:
   ```bash
   python scanner.py
   ```
7. Enter the date (`YYYY-MM-DD`) and NSE advances/declines at 9:30 when prompted.

## Excel sheets
- `Candles`: fetched 5-minute candles
- `Setups`: candidate signals, triggered or cancelled
- `Trades`: entry, SL, target, exit time/price, P&L and status

P&L is per share × quantity. Set `QUANTITY` in `.env` for a simple per-stock paper quantity. This starter does not apply lot sizes, brokerage, taxes, slippage or exchange charges.
