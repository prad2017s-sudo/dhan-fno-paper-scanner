import os
import sys
from datetime import datetime, time
from zoneinfo import ZoneInfo

import pandas as pd
import requests
from dotenv import load_dotenv

load_dotenv()
IST = ZoneInfo("Asia/Kolkata")
API_URL = "https://api.dhan.co/v2/charts/intraday"
TOKEN = os.getenv("DHAN_ACCESS_TOKEN", "").strip()
QUANTITY = int(os.getenv("QUANTITY", "1"))
EXCEL_FILE = os.getenv("EXCEL_FILE", "paper_trading.xlsx")

COLUMNS_CANDLES = ["date", "symbol", "timestamp", "open", "high", "low", "close", "volume"]
COLUMNS_SETUPS = [
    "date", "symbol", "bias", "setup_time", "setup_open", "setup_high",
    "setup_low", "setup_close", "setup_volume", "trigger_price", "stop_loss",
    "valid_for_time", "status", "note"
]
COLUMNS_TRADES = [
    "date", "symbol", "side", "setup_time", "entry_time", "entry_price",
    "stop_loss", "target_price", "exit_time", "exit_price", "quantity",
    "risk_per_share", "pnl_gross", "status", "exit_reason"
]


def fetch_candles(symbol_row, day):
    """Fetch one session's 5-minute OHLCV candles from Dhan."""
    if not TOKEN:
        raise RuntimeError("DHAN_ACCESS_TOKEN .env file mein set karein.")
    sid = str(symbol_row["security_id"]).strip()
    if not sid.isdigit() or sid == "0":
        raise ValueError(f"{symbol_row['symbol']}: symbols.csv mein valid security_id bharein.")

    payload = {
        "securityId": sid,
        "exchangeSegment": str(symbol_row["exchange_segment"]).strip(),
        "instrument": str(symbol_row["instrument"]).strip(),
        "interval": "5",
        "oi": False,
        "fromDate": f"{day} 09:15:00",
        "toDate": f"{day} 15:30:00",
    }
    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "access-token": TOKEN,
    }
    response = requests.post(API_URL, json=payload, headers=headers, timeout=30)
    if response.status_code != 200:
        raise RuntimeError(f"Dhan API error {response.status_code}: {response.text[:400]}")
    result = response.json()
    data = result.get("data", result)
    if not isinstance(data, dict) or "timestamp" not in data:
        raise RuntimeError(f"{symbol_row['symbol']}: unexpected Dhan response: {str(result)[:400]}")

    frame = pd.DataFrame({
        "timestamp": data.get("timestamp", []),
        "open": data.get("open", []),
        "high": data.get("high", []),
        "low": data.get("low", []),
        "close": data.get("close", []),
        "volume": data.get("volume", []),
    })
    if frame.empty:
        return pd.DataFrame(columns=COLUMNS_CANDLES)
    frame["timestamp"] = pd.to_datetime(frame["timestamp"], unit="s", utc=True).dt.tz_convert(IST).dt.tz_localize(None)
    frame = frame.sort_values("timestamp").drop_duplicates("timestamp")
    frame = frame[(frame["timestamp"].dt.date == datetime.strptime(day, "%Y-%m-%d").date())]
    frame = frame[(frame["timestamp"].dt.time >= time(9, 15)) & (frame["timestamp"].dt.time <= time(15, 30))]
    for col in ["open", "high", "low", "close", "volume"]:
        frame[col] = pd.to_numeric(frame[col], errors="coerce")
    frame = frame.dropna(subset=["open", "high", "low", "close", "volume"])
    frame["date"] = day
    frame["symbol"] = str(symbol_row["symbol"]).strip()
    return frame[COLUMNS_CANDLES].reset_index(drop=True)


def get_bias(advances, declines):
    if advances > declines:
        return "BUY"
    if declines > advances:
        return "SELL"
    return "NONE"


def simulate_symbol(frame, bias, day):
    """One setup can trigger only on the immediately following 5-minute candle."""
    setups, trades = [], []
    if frame.empty or bias == "NONE":
        return setups, trades

    frame = frame.sort_values("timestamp").reset_index(drop=True)
    session_start = time(9, 15)
    decision_time = time(9, 30)
    frame = frame[frame["timestamp"].dt.time >= session_start].reset_index(drop=True)
    # Breadth is taken at 9:30, so only candles starting at/after 9:30 are new setup candidates.
    # Dhan timestamps are treated as candle start times.
    i = 0
    while i < len(frame):
        candle = frame.iloc[i]
        ctime = candle["timestamp"].time()
        if ctime < decision_time:
            i += 1
            continue

        # A setup must have at least one earlier candle, and volume must be lower
        # than every earlier candle in this session (strictly lower than the minimum).
        prior = frame.iloc[:i]
        if prior.empty:
            i += 1
            continue
        is_red = candle["close"] < candle["open"]
        is_green = candle["close"] > candle["open"]
        color_ok = is_red if bias == "BUY" else is_green
        low_volume = candle["volume"] < prior["volume"].min()

        if not (color_ok and low_volume):
            i += 1
            continue

        side = bias
        trigger = float(candle["high"] if side == "BUY" else candle["low"])
        sl = float(candle["low"] if side == "BUY" else candle["high"])
        setup_time = candle["timestamp"]
        if i + 1 >= len(frame):
            setups.append({
                "date": day, "symbol": candle["symbol"], "bias": side,
                "setup_time": setup_time, "setup_open": candle["open"],
                "setup_high": candle["high"], "setup_low": candle["low"],
                "setup_close": candle["close"], "setup_volume": candle["volume"],
                "trigger_price": trigger, "stop_loss": sl, "valid_for_time": None,
                "status": "EXPIRED_NO_NEXT_CANDLE", "note": "Next candle unavailable in fetched data"
            })
            i += 1
            continue

        next_candle = frame.iloc[i + 1]
        next_time = next_candle["timestamp"]
        hit = float(next_candle["high"]) >= trigger if side == "BUY" else float(next_candle["low"]) <= trigger
        setups.append({
            "date": day, "symbol": candle["symbol"], "bias": side,
            "setup_time": setup_time, "setup_open": candle["open"],
            "setup_high": candle["high"], "setup_low": candle["low"],
            "setup_close": candle["close"], "setup_volume": candle["volume"],
            "trigger_price": trigger, "stop_loss": sl, "valid_for_time": next_time,
            "status": "TRIGGERED" if hit else "CANCELLED",
            "note": "Trigger touched in next candle" if hit else "Trigger not touched in next candle"
        })
        if not hit:
            i += 1
            continue

        entry = trigger
        risk = abs(entry - sl)
        if risk <= 0:
            i += 1
            continue
        target = entry + 2 * risk if side == "BUY" else entry - 2 * risk
        exit_price, exit_time, exit_reason, status = None, None, None, "OPEN_AT_END"

        # Starting at trigger candle, evaluate the rest of the session.
        # If both SL and target are touched in the same candle, conservatively assume SL first.
        for j in range(i + 1, len(frame)):
            bar = frame.iloc[j]
            if side == "BUY":
                sl_hit = float(bar["low"]) <= sl
                target_hit = float(bar["high"]) >= target
            else:
                sl_hit = float(bar["high"]) >= sl
                target_hit = float(bar["low"]) <= target

            if sl_hit:
                exit_price, exit_time, exit_reason, status = sl, bar["timestamp"], "STOP_LOSS", "CLOSED"
                break
            if target_hit:
                exit_price, exit_time, exit_reason, status = target, bar["timestamp"], "TARGET_1_TO_2", "CLOSED"
                break

        if exit_price is None:
            last = frame.iloc[-1]
            exit_price, exit_time, exit_reason = float(last["close"]), last["timestamp"], "SESSION_END_MARK_TO_MARK"

        pnl = (exit_price - entry) * QUANTITY if side == "BUY" else (entry - exit_price) * QUANTITY
        trades.append({
            "date": day, "symbol": candle["symbol"], "side": side,
            "setup_time": setup_time, "entry_time": next_time, "entry_price": entry,
            "stop_loss": sl, "target_price": target, "exit_time": exit_time,
            "exit_price": exit_price, "quantity": QUANTITY,
            "risk_per_share": risk, "pnl_gross": pnl, "status": status,
            "exit_reason": exit_reason
        })
        # Avoid overlapping positions for the same symbol in this simple starter.
        break

    return setups, trades


def write_excel(candles, setups, trades, advances, declines, bias, day):
    meta = pd.DataFrame([{
        "date": day, "NSE_advances_at_930": advances,
        "NSE_declines_at_930": declines, "market_bias": bias,
        "note": "Paper simulation only; no live orders sent"
    }])
    mode = "a" if os.path.exists(EXCEL_FILE) else "w"
    with pd.ExcelWriter(EXCEL_FILE, engine="openpyxl", mode=mode,
                        if_sheet_exists="replace" if mode == "a" else None) as writer:
        meta.to_excel(writer, sheet_name="Summary", index=False)
        (candles if not candles.empty else pd.DataFrame(columns=COLUMNS_CANDLES)).to_excel(
            writer, sheet_name="Candles", index=False)
        (pd.DataFrame(setups) if setups else pd.DataFrame(columns=COLUMNS_SETUPS)).to_excel(
            writer, sheet_name="Setups", index=False)
        (pd.DataFrame(trades) if trades else pd.DataFrame(columns=COLUMNS_TRADES)).to_excel(
            writer, sheet_name="Trades", index=False)


def main():
    print("\nDhan NSE F&O 5-minute PAPER scanner — no real orders")
    day = input("Trading date (YYYY-MM-DD, e.g. 2026-10-12): ").strip()
    try:
        datetime.strptime(day, "%Y-%m-%d")
    except ValueError:
        sys.exit("Date format galat hai. YYYY-MM-DD use karein.")

    try:
        advances = int(input("9:30 NSE Advances count: ").strip())
        declines = int(input("9:30 NSE Declines count: ").strip())
    except ValueError:
        sys.exit("Advances aur Declines integer hone chahiye.")

    bias = get_bias(advances, declines)
    print(f"Market bias: {bias}")
    if bias == "NONE":
        print("Advances aur declines barabar hain. Koi trade setup simulate nahi hoga.")

    symbols = pd.read_csv("symbols.csv", dtype=str).fillna("")
    if len(symbols) != 10:
        print(f"Warning: symbols.csv mein {len(symbols)} rows hain; target 10 rows hai.")

    all_candles, all_setups, all_trades = [], [], []
    for _, row in symbols.iterrows():
        symbol = row["symbol"].strip()
        if not symbol or symbol.startswith("REPLACE_"):
            print(f"Skipping placeholder row: {symbol}")
            continue
        try:
            candles = fetch_candles(row, day)
            if candles.empty:
                print(f"{symbol}: no candles returned")
                continue
            print(f"{symbol}: {len(candles)} candles")
            setups, trades = simulate_symbol(candles, bias, day)
            all_candles.append(candles)
            all_setups.extend(setups)
            all_trades.extend(trades)
        except Exception as exc:
            print(f"{symbol}: ERROR: {exc}")

    combined = pd.concat(all_candles, ignore_index=True) if all_candles else pd.DataFrame(columns=COLUMNS_CANDLES)
    write_excel(combined, all_setups, all_trades, advances, declines, bias, day)
    print(f"\nExcel saved: {EXCEL_FILE}")
    print(f"Setups: {len(all_setups)} | Paper trades: {len(all_trades)}")
    print("Reminder: historical simulation only. Verify every rule before live use.")


if __name__ == "__main__":
    main()
